﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux = "";
            double soma = 0.0;
            string media = "Medias dos Alunos\n\n";

            for (int i = 0; i < notas.GetLength(0); i++) 
            {
                soma = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"aluno{i + 1} nota{j + 1}", "entrada de dados");
                    {
                        if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                        {
                            MessageBox.Show("Digite uma nota valida");
                            j--;
                        }
                        else 
                        {
                            soma += notas[i, j];
                        }
                    }
                }
                soma = soma / 3;
                media += $"aluno{i + 1}: Média{soma:N2}\n";
            }
            MessageBox.Show(media);
        }
    }
}
