﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraLP2
{
    public partial class Form1 : Form
    {
        double Num1;
        double Num2;
        double Result;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNum1_Validating(object sender, CancelEventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }


            if (!double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Numero invalido");
                e.Cancel = true;
            }
            
           

            

            

        }

        private void txtNum2_Validating(object sender, CancelEventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }


            if (!double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("Numero invalido");
                e.Cancel = true;
            }
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            Result = Num1 + Num2;
            txtResultado.Text = Result.ToString();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            Result = Num1 - Num2;
            txtResultado.Text = Result.ToString();
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            Result = Num1 * Num2;
            txtResultado.Text = Result.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Num2 != 0)
            {
                Result = Num1 / Num2;
                txtResultado.Text = Result.ToString("N3");
            }
            else
            {
                MessageBox.Show("Tem que ser maior que 0");
                txtNum2.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Text = "";
            txtResultado.Text = string.Empty;

            Num1 = 0;
            Num2 = 0;
            Result = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
