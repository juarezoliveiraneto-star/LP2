﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMCLP2
{
    public partial class Form1 : Form
    {
        double Peso;
        double Altura;
        double Imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtPeso_Validating(object sender, CancelEventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Peso Invãlido");
                e.Cancel = true;
            }
            if (Peso <= 0)
            {
                MessageBox.Show("Coloque seu peso");
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validating(object sender, CancelEventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Altura Invãlida");
                e.Cancel = true;
            }
            if (Altura <= 0)
            {
                MessageBox.Show("Coloque sua altura");
                txtAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Imc = Peso / (Altura * Altura);
            txtIMC.Text = Imc.ToString("N1");

            if (Imc < 18.5)
            {
                MessageBox.Show("Magreza, Obesidade grau 0");
                txtClass.Text = "Magreza";
                txtGrau.Text = "0";
            }
            else if (Imc <= 24.9)
            {
                MessageBox.Show("Normal, Obesidade grau 0");
                txtClass.Text = "Normal";
                txtGrau.Text = "0";
            }
            else if (Imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso, Obesidade grau 1");
                txtClass.Text = "Sobrepeso";
                txtGrau.Text = "1";
            }
            else if (Imc <= 39.9)
            {
                MessageBox.Show("Obesidade, Obesidade grau 2");
                txtClass.Text = "Obesidade";
                txtGrau.Text = "2";
            }
            else
            {
                MessageBox.Show("Obesidade Grave, Obesidade grau 3");
                txtClass.Text = "Obesidade Grave";
                txtGrau.Text = "3";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtIMC.Clear();
            txtGrau.Clear();
            txtClass.Clear();
            txtAltura.Clear();

            Peso = 0;
            Altura = 0;
            Imc = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
