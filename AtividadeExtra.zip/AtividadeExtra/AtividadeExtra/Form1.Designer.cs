﻿namespace AtividadeExtra
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCompras = new System.Windows.Forms.Button();
            this.ltbxCompras = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnCompras
            // 
            this.btnCompras.Location = new System.Drawing.Point(74, 117);
            this.btnCompras.Name = "btnCompras";
            this.btnCompras.Size = new System.Drawing.Size(192, 109);
            this.btnCompras.TabIndex = 0;
            this.btnCompras.Text = "Compras";
            this.btnCompras.UseVisualStyleBackColor = true;
            this.btnCompras.Click += new System.EventHandler(this.btnCompras_Click);
            // 
            // ltbxCompras
            // 
            this.ltbxCompras.FormattingEnabled = true;
            this.ltbxCompras.ItemHeight = 20;
            this.ltbxCompras.Location = new System.Drawing.Point(343, 32);
            this.ltbxCompras.Name = "ltbxCompras";
            this.ltbxCompras.Size = new System.Drawing.Size(296, 384);
            this.ltbxCompras.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ltbxCompras);
            this.Controls.Add(this.btnCompras);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCompras;
        private System.Windows.Forms.ListBox ltbxCompras;
    }
}

