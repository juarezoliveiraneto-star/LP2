﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace AtividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompras_Click(object sender, EventArgs e)
        {
            double[,] Compras = new double[7,5];
            string aux = "";
            string[] semana = { "Domingo", "Segunda ", "Terca", "Quarta", "Quinta", "Sexta", "Sabado"};
            double[] VetorLinha = new double[7];
            double TotalGeral = 0;

            for (int i = 0; i < 7 ; i++)
            {
                double ValLinhas = 0;
                for (int j = 0; j < 5 ; j++)
                {
                    aux = Interaction.InputBox($"{semana[i]} Produto {j + 1}");
                    if ( aux == "")
                    {
                        return;
                    }
                    if (!double.TryParse(aux, out Compras[i, j]) || Compras[i, j] < 0)
                    {
                        MessageBox.Show("Digite  Valor da Compra");
                        j--;
                    }
                    else
                    {
                        ValLinhas += Compras[i, j];
                    }
                }
                VetorLinha[i] = ValLinhas;
            }
            
            for (int i = 0;i < 7 ; i++)
            {
                TotalGeral += VetorLinha[i];
            }

            for (int i = 0;i < 7 ; i++)
            {
                ltbxCompras.Items.Add($"{semana[i]} {VetorLinha[i]:c}");
            }
            ltbxCompras.Items.Add($"\nTotal geral: {TotalGeral:c}");
        }
    }
}
