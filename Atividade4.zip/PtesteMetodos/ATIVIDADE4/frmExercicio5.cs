﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE4
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out int numero1) || !int.TryParse(txtNumero2.Text, out int numero2))
            {
                return;
            }
            Random Obj = new Random();
            int Sorteio = Obj.Next(numero1, numero2);
            MessageBox.Show(Sorteio.ToString());
        }
    }
}
