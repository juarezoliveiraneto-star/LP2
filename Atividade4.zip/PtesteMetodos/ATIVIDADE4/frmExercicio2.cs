﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE4
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text,txtPalavra2.Text,true) == 0)
            {
                MessageBox.Show("Os textos sao iguais");
            }
            else
                MessageBox.Show("Os textos nao sao iguais");
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int Meio = txtPalavra2.Text.Length / 2;
            txtPalavra2.Text = txtPalavra2.Text.Substring(0, Meio) + (txtPalavra1.Text + txtPalavra2.Text.Substring(Meio, txtPalavra2.Text.Length - Meio)); 
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int Mei = txtPalavra1.Text.Length / 2;
            txtPalavra2.Text = txtPalavra1.Text.Substring(0, Mei) + "**" + txtPalavra1.Text.Substring(Mei, txtPalavra1.Text.Length - Mei);
        }
    }
}
