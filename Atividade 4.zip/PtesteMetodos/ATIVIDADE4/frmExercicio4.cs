﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE4
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ContNum=0;
            int contador = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    ContNum++;
                }

                contador++;
            }

            MessageBox.Show("A frase tem " + ContNum + " numeros");
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            int posicao = -1;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            if (posicao >= 0)
            {
                MessageBox.Show("O Primeiro caracter em branco esta na posicao " + posicao);
            }
            else
            {
                MessageBox.Show("Nao ha espaços en branco");
            }
                
        }
    }
}
