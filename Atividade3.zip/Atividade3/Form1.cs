﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        double Lado1, Lado2, Lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtLado2, "");

                Lado2 = Convert.ToDouble(txtLado2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtLado2, "Valor invalido");
            }
        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider3.SetError(txtLado3, "");

                Lado3 = Convert.ToDouble(txtLado3.Text);
            }
            catch
            {
                errorProvider3.SetError(txtLado3, "Valor invalido");
            }
        }

        private void btnExecut_Click(object sender, EventArgs e)
        {
            if ((Lado1 < (Lado2 + Lado3)) && (Lado1 > (Math.Abs(Lado2 - Lado3))) && (Lado2 < (Lado1 + Lado3)) && (Lado2 > (Math.Abs(Lado1 - Lado3))) && (Lado3 < (Lado1 + Lado2)) && (Lado3 > (Math.Abs(Lado1 - Lado2))))
            {
                if (Lado1 == Lado2 && Lado2 == Lado3)
                {
                    MessageBox.Show("Triangulo Equilatero");
                }
                else if (Lado1 == Lado2 || Lado1 == Lado3 || Lado2 == Lado3)
                {
                    MessageBox.Show("Triangulo Isosceles");
                }
                else
                {
                    MessageBox.Show("Triangulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Nao forma um triangulo");
            }
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();

            Lado1 = 0;
            Lado2 = 0;
            Lado3 = 0;
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtLado1, "");

                Lado1 = Convert.ToDouble(txtLado1.Text);
            }
            catch
            {
                errorProvider1.SetError(txtLado1, "Valor invalido");
            }
        }
    }
}
